// File tieu de (header file): chua khai bao cac khuon mau ham
#include<stdio.h>

#define MAX 100
// Khai bao cac khuon mau ham (prototypes)
void NhapMang(int a[], int &n);
void NhapMangTuFile(char fname[], int a[], int &n);
void XuatMang(int a[], int n);
void SapXepTangDan(int a[], int n);
void GhiMangVaoFile(char fname[], int a[], int n);

